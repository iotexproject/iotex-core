//go:binary-only-package

package bn256

import "github.com/CoderZhi/go-ethereum/crypto/bn256/cloudflare"
