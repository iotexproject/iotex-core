//go:binary-only-package

package sha3
