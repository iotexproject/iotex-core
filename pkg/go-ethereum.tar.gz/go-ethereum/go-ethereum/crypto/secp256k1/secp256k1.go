//go:binary-only-package

package secp256k1
