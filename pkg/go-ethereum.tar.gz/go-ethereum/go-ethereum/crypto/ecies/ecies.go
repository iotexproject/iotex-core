//go:binary-only-package

package ecies
