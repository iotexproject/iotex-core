//go:binary-only-package

package types
