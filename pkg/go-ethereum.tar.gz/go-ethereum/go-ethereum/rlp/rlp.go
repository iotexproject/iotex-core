//go:binary-only-package

package rlp
