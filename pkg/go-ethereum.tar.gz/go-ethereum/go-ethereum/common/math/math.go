//go:binary-only-package

package math
