//go:binary-only-package

package hexutil
