This package is a fork of https://github.com/inconshreveable/log15, with some
minor modifications required by the go-ethereum codebase:

 * Support for log level `trace`
 * Modified behavior to exit on `critical` failure
